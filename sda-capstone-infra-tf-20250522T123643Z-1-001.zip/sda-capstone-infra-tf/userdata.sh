#!/bin/bash
apt-get update -y
apt-get upgrade -y
apt-get install git -y
apt-get install python3 -y
apt install python3-pip -y
pip3 install boto3
apt  install awscli -y
cd /home/ubuntu/
TOKEN=$(aws --region=eu-central-1 ssm get-parameter --name ${ssm-git-token} --query 'Parameter.Value' --output text)
git clone https://$TOKEN@github.com/shinesly201/infrastructure-capstone.git
cd /home/ubuntu/infrastructure-capstone
apt-get install python3.10-dev default-libmysqlclient-dev -y
pip3 install -r requirements.txt
cd /home/ubuntu/infrastructure-capstone/src
python3 manage.py collectstatic --noinput
python3 manage.py makemigrations
python3 manage.py migrate
python3 manage.py runserver 0.0.0.0:80
